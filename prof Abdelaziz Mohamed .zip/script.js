
/* =====================================
   PROF. DR. ABDEL AZIZ
   ACADEMIC WEBSITE
===================================== */


/* =====================================
   1. LANGUAGE SWITCHER
===================================== */

const languageBtn = document.getElementById("languageBtn");

let currentLanguage = "ar";

function changeLanguage() {

    if (!languageBtn) return;

    const elements = document.querySelectorAll("[data-ar][data-en]");

    if (currentLanguage === "ar") {

        currentLanguage = "en";

        document.documentElement.lang = "en";
        document.documentElement.dir = "ltr";
        document.body.dir = "ltr";

        languageBtn.textContent = "AR";

    } else {

        currentLanguage = "ar";

        document.documentElement.lang = "ar";
        document.documentElement.dir = "rtl";
        document.body.dir = "rtl";

        languageBtn.textContent = "EN";
    }

    elements.forEach(element => {

        element.textContent = element.getAttribute(
            `data-${currentLanguage}`
        );

    });

}

if (languageBtn) {
    languageBtn.addEventListener("click", changeLanguage);
}


/* =====================================
   2. CURRENT YEAR
===================================== */

const currentYear = document.getElementById("currentYear");

if (currentYear) {
    currentYear.textContent = new Date().getFullYear();
}


/* =====================================
   3. BACK TO TOP
===================================== */

const backToTop = document.getElementById("backToTop");

if (backToTop) {

    backToTop.addEventListener("click", function() {

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });

    });

    backToTop.style.opacity = "0";
    backToTop.style.visibility = "hidden";

    window.addEventListener("scroll", function() {

        if (window.scrollY > 400) {

            backToTop.style.opacity = "1";
            backToTop.style.visibility = "visible";

        } else {

            backToTop.style.opacity = "0";
            backToTop.style.visibility = "hidden";

        }

    });

}


/* =====================================
   4. ACADEMIC GALLERY LIGHTBOX
===================================== */

(function() {

    const galleryImages = document.querySelectorAll(".gallery-item img");

    const lightbox = document.getElementById("galleryLightbox");
    const lightboxImage = document.getElementById("lightboxImage");

    const closeButton = document.getElementById("closeLightbox");
    const nextButton = document.getElementById("nextImage");
    const prevButton = document.getElementById("prevImage");

    if (
        !lightbox ||
        !lightboxImage ||
        !closeButton ||
        !nextButton ||
        !prevButton ||
        galleryImages.length === 0
    ) {
        return;
    }

    let currentIndex = 0;

    function showImage(index) {

        currentIndex =
            (index + galleryImages.length) % galleryImages.length;

        lightboxImage.src = galleryImages[currentIndex].src;

        lightbox.classList.add("active");

        document.body.style.overflow = "hidden";
    }

    function closeGallery() {

        lightbox.classList.remove("active");

        document.body.style.overflow = "";

        lightboxImage.src = "";
    }

    galleryImages.forEach((image, index) => {

        image.parentElement.addEventListener("click", function() {
            showImage(index);
        });

    });

    closeButton.addEventListener("click", closeGallery);

    nextButton.addEventListener("click", function() {
        showImage(currentIndex + 1);
    });

    prevButton.addEventListener("click", function() {
        showImage(currentIndex - 1);
    });

    lightbox.addEventListener("click", function(event) {

        if (event.target === lightbox) {
            closeGallery();
        }

    });

    document.addEventListener("keydown", function(event) {

        if (!lightbox.classList.contains("active")) return;

        if (event.key === "Escape") {
            closeGallery();
        }

        if (event.key === "ArrowRight") {
            showImage(currentIndex + 1);
        }

        if (event.key === "ArrowLeft") {
            showImage(currentIndex - 1);
        }

    });

})();


/* =====================================
   5. PREMIUM INTRO
   ROYAL ACADEMIC SOUND
===================================== */

(function() {

    function setupPremiumIntro() {

        const intro = document.getElementById("premiumIntro");
        const enterButton = document.getElementById("enterWebsite");

        if (!intro || !enterButton) {
            console.log("Premium Intro elements not found");
            return;
        }

        document.body.style.overflow = "hidden";

        let hasEntered = false;

        enterButton.addEventListener("click", function(event) {

            event.preventDefault();

            if (hasEntered) return;

            hasEntered = true;

            /* ROYAL ACADEMIC SOUND */

            try {

                const AudioContextClass =
                    window.AudioContext || window.webkitAudioContext;

                if (AudioContextClass) {

                    const audio = new AudioContextClass();

                    const notes = [
                        261.63,
                        329.63,
                        392.00,
                        523.25
                    ];

                    notes.forEach((frequency, index) => {

                        const oscillator = audio.createOscillator();
                        const gain = audio.createGain();

                        oscillator.type = "sine";
                        oscillator.frequency.value = frequency;

                        const startTime = audio.currentTime + index * 0.08;

                        gain.gain.setValueAtTime(0, startTime);

                        gain.gain.linearRampToValueAtTime(
                            0.045,
                            startTime + 0.15
                        );

                        gain.gain.exponentialRampToValueAtTime(
                            0.001,
                            startTime + 1.8
                        );

                        oscillator.connect(gain);
                        gain.connect(audio.destination);

                        oscillator.start(startTime);
                        oscillator.stop(startTime + 2);

                    });

                    setTimeout(function() {
                        audio.close();
                    }, 2500);

                }

            } catch (error) {

                console.log("Audio could not be played:", error);

            }

            /* ENTER WEBSITE */

            intro.classList.add("intro-exit");

            document.body.style.overflow = "";

            setTimeout(function() {

                intro.style.display = "none";

            }, 950);

        });

    }

    if (document.readyState === "loading") {

        document.addEventListener("DOMContentLoaded", setupPremiumIntro);

    } else {

        setupPremiumIntro();

    }

})();


/* =====================================
   WEBSITE READY
===================================== */

console.log("Academic Website Loaded Successfully");
// CINEMATIC SCROLL REVEAL

const revealElements = document.querySelectorAll(
    "section, .hero-content, .gallery-item, .timeline-item"
);

revealElements.forEach(element => {
    element.classList.add("reveal");
});

const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add("active");
            revealObserver.unobserve(entry.target);
        }
    });
}, {
    threshold: 0.15
});

revealElements.forEach(element => {
    revealObserver.observe(element);
});

// ACADEMIC EXPERIENCE COUNTER

const experienceCounter = document.querySelector(
    '#academicHighlights [data-target="30"]'
);

if (experienceCounter) {
    let counterStarted = false;

    const counterObserver = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting && !counterStarted) {
                counterStarted = true;

                let current = 0;
                const target = 30;

                const timer = setInterval(() => {
                    current++;

                    experienceCounter.textContent = current + "+";

                    if (current >= target) {
                        clearInterval(timer);
                    }
                }, 55);

                counterObserver.disconnect();
            }
        });
    }, { threshold: 0.5 });

    counterObserver.observe(experienceCounter);
}

// ==============================
// DAILY ACADEMIC QUOTE
// ==============================

const dailyQuotes = [
    {
        ar: "العلم لا يتوقف عند حدود المعرفة، بل يبدأ منها طريق الاكتشاف.",
        en: "Knowledge does not end at understanding; it begins the journey of discovery."
    },
    {
        ar: "البحث العلمي هو الطريق نحو مستقبل أفضل.",
        en: "Scientific research is the path toward a better future."
    },
    {
        ar: "كل اكتشاف عظيم بدأ بسؤال يستحق البحث.",
        en: "Every great discovery began with a question worth exploring."
    },
    {
        ar: "التعليم استثمار في العقول، وأثره يمتد عبر الأجيال.",
        en: "Education is an investment in minds, with an impact across generations."
    },
    {
        ar: "الإصرار على التعلم هو بداية التميز.",
        en: "The commitment to learning is the beginning of excellence."
    },
    {
        ar: "قيمة العلم تظهر عندما يتحول إلى معرفة نافعة.",
        en: "The value of science emerges when it becomes useful knowledge."
    },
    {
        ar: "العقل الباحث لا يتوقف عن طرح الأسئلة.",
        en: "A curious mind never stops asking questions."
    }
];

const quoteSection = document.getElementById("dailyQuote");

if (quoteSection) {
    const today = new Date();
    const dateKey = today.getFullYear() * 10000
        + (today.getMonth() + 1) * 100
        + today.getDate();

    const quoteIndex = dateKey % dailyQuotes.length;
    const quoteHeading = quoteSection.querySelector(".quote-content h2");

    if (quoteHeading) {
        quoteHeading.dataset.ar = dailyQuotes[quoteIndex].ar;
        quoteHeading.dataset.en = dailyQuotes[quoteIndex].en;

        const currentLanguage =
            document.documentElement.lang === "en" ? "en" : "ar";

        quoteHeading.textContent = dailyQuotes[quoteIndex][currentLanguage];
    }
}
